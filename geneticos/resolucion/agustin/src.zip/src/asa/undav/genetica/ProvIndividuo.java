package asa.undav.genetica;

public interface ProvIndividuo {
	
	public Individuo getIndividuo();
	
}
